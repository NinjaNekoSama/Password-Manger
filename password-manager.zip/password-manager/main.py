from tkinter import *
from tkinter import messagebox
import random
import pyperclip
import json


# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_functions():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v',
               'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
               'R',
               'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_letters = [random.choice(letters) for _ in range(nr_letters)]
    password_symbols = [random.choice(symbols) for _ in range(nr_symbols)]
    password_numbers = [random.choice(numbers) for _ in range(nr_numbers)]

    password_list = password_letters + password_symbols + password_numbers

    random.shuffle(password_list)

    password = "".join(password_list)

    # password = ""
    # for char in password_list:
    #     password += char
    # print(f"Your password is: {password}")
    secret_password.insert(0, password)
    pyperclip.copy(password)


# ---------------------------- SAVE PASSWORD ------------------------------- #

def save():
    web = website.get()
    passpass = secret_password.get()
    mail = email.get()
    new_dict = {
        web: {
            "email": mail,
            "password": passpass,
        }
    }

    if website.get() == "" or passpass == "" or mail == "":
        messagebox.showinfo(title="Warning", message="Don't leave the fields empty")
    else:
        is_okay = messagebox.askokcancel(title=web,
                                         message=f"These are the details entered "
                                                 f"email :{mail}\n password : {passpass}\n "
                                                 f"is it okay to save? ")
        my_list = {"Website Name": web, "Email ID": mail, "Password": passpass}
        if is_okay:
            try:
                with open("data.json", 'r') as f:
                    data = json.load(f)
                    # print(data)
                    data.update(new_dict)
            except FileNotFoundError:
                with open("data.json", 'w') as f:
                    json.dump(new_dict, f, indent=4)
            else:
                with open("data.json", 'r') as f:
                    data = json.load(f)
                    # print(data)
                    data.update(new_dict)
                    with open("data.json", 'w') as f:
                        json.dump(data, f, indent=4)
            finally:
                website.delete(0, 'end')
                secret_password.delete(0, 'end')
                email.delete(0, 'end')


# ---------------------------- SEARCH ------------------------------- #

def find_password():
    try:
        with open("data.json", 'r') as f:
            data = json.load(f)
            try:
                my_website = data[website.get()]
                messagebox.showinfo(title="Info", message=f"The email ID is {data[website.get()]['email']}\n"
                                                          f"The password is {data[website.get()]['password']} ")
            except KeyError:
                messagebox.showinfo(title="ERROR", message="No such website in the current Database!")
    except FileNotFoundError:
        messagebox.showinfo(title="ERROR", message="No such file found in the database")


# ---------------------------- UI SETUP ------------------------------- #
window = Tk()
window.title("Password manager")
window.config(padx=20, pady=20)

canvas = Canvas(width=200, height=200)
img = PhotoImage(file="logo.png")
canvas.create_image(110, 110, image=img)
canvas.grid(row=0, column=2)

label = Label(text="Website")
label.grid(column=1, row=2)

website = Entry(width=35)
website.grid(row=2, column=2, columnspan=2)
website.focus()

email = Entry(width=35)
email.grid(row=3, column=2, columnspan=2)

label1 = Label(text="Email/Username")
label1.grid(column=1, row=3)

Generate = Button(text="Generate Password", command=generate_functions)
Generate.grid(column=4, row=4)

secret_password = Entry(width=35)
secret_password.grid(row=4, column=2, columnspan=2)

label2 = Label(text="Password")
label2.grid(column=1, row=4)

add = Button(text="Add", width=35, command=save)
add.grid(column=2, row=5, columnspan=2)

search = Button(text="Search", width=15, command=find_password)
search.grid(column=4, row=2, columnspan=10)

window.mainloop()
